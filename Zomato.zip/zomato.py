import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
plt.style.use('dark_background')

zomato_df=pd.read_csv("E:/SEM 5/Python/zz.csv")
#print(zomato_df.head())

#-------------------------------------------------------------------------------------
#total rows & column
#print(zomato_df.shape)

#---------------------------------------------------------------------------------------
#Columns Name
#print(zomato_df.columns)

#---------------------------------------------------------------------------------------
#will return True if null values are there
nan_v = zomato_df.isna()
nan_c = nan_v.any()
#print(nan_c)

#Total Null vales
#print(zomato_df.isnull().sum())

#---------------------------------------------------------------------------------------
#droping column
zomato_df = zomato_df.drop(['url', 'address', 'phone', 'menu_item', 'dish_liked', 'reviews_list'], axis = 1)
#print(zomato_df.columns)

#---------------------------------------------------------------------------------------
#Info
#print(zomato_df.info())

#---------------------------------------------------------------------------------------
#dropping Duplicates
zomato_df.drop_duplicates(inplace = True)
#print(zomato_df.shape)

#---------------------------------------------------------------------------------------
#Values of particular Column
#print(zomato_df['rate'].unique())

#Removing "NEW","-" and "/5" from Rate Column
def handlerate(value):
    if(value=='NEW' or value=='-'):
        return np.nan
    else:
        value = str(value).split('/')
        value = value[0]
        return float(value)
zomato_df['rate'] = zomato_df['rate'].apply(handlerate)
#print(zomato_df['rate'].head(10))

#---------------------------------------------------------------------------------------
#print(zomato_df.info())
#filling null values in rate

#print(zomato_df.rate.isnull().sum())
#zomato_df['rate'].fillna(zomato_df['rate'].mean(), inplace = True)
#print(zomato_df['rate'].isnull().sum())

#---------------------------------------------------------------------------------------
#dropping null values rows
zomato_df.dropna(inplace = True)
#print(zomato_df.head())
#print(zomato_df.info())

#---------------------------------------------------------------------------------------
#Droping listed_in(city)......Listed in(city) and location, both are there, lets keep only one.
zomato_df = zomato_df.drop(['listed_in(city)'], axis = 1)

#---------------------------------------------------------------------------------------
#renaming column
zomato_df.rename(columns = {'approx_cost(for two people)':'Cost2plates', 'listed_in(type)':'Type'}, inplace = True)
#print(zomato_df.head())

#---------------------------------------------------------------------------------------
#print(zomato_df['Cost2plates'].unique())
#Removing , from Cost2Plates Column

def handlecomma(value):
    value = str(value)
    if ',' in value:
        value = value.replace(',', '')
        return float(value)
    else:
        return float(value)
zomato_df['Cost2plates'] = zomato_df['Cost2plates'].apply(handlecomma)
#print(zomato_df['Cost2plates'].unique())

#---------------------------------------------------------------------------------------
rest_types = zomato_df['rest_type'].value_counts(ascending = False)
#print(rest_types)

#rest type having less than 1000 values are grouped as other
rest_types_lessthan1000 = rest_types[rest_types<1000]
#print(rest_types_lessthan1000)

def handle_rest_type(value):
    if(value in rest_types_lessthan1000):
        return 'others'
    else:
        return value
zomato_df['rest_type'] = zomato_df['rest_type'].apply(handle_rest_type)
#print(zomato_df['rest_type'].value_counts())

#---------------------------------------------------------------------------------------
#location having less than 1000 values are grouped as other
#print(zomato_df['location'].value_counts())

location = zomato_df['location'].value_counts(ascending = False)
location_lessthan300 = location[location<300]
#print(location_lessthan300)

def handle_location(value):
    if(value in location_lessthan300):
        return 'others'
    else:
        return value
zomato_df['location'] = zomato_df['location'].apply(handle_location)
#print(zomato_df['location'].value_counts())

#---------------------------------------------------------------------------------------
#print(zomato_df['cuisines'].value_counts())

#cuisines having less than 1000 values are grouped as other
cuisines = zomato_df['cuisines'].value_counts(ascending = False)
cuisines_lessthan100 = cuisines[cuisines<100]
#print(cuisines_lessthan100)

def handle_cuisines(value):
    if(value in cuisines_lessthan100):
        return 'others'
    else:
        return value
zomato_df['cuisines'] = zomato_df['cuisines'].apply(handle_cuisines)
#print(zomato_df['cuisines'].value_counts())

#---------------------------------------------------------------------------------------
#Count Plot of Various Locations
warnings.simplefilter(action='ignore', category=FutureWarning)
#plt.figure(figsize=(15,7))
#chains=zomato_df['location'].value_counts()
#sns.barplot(x=chains,y=chains.index,palette='Set2')
#plt.title("No. of Restaurant per Location",size=20,pad=10)
#plt.ylabel("Location",size=15)
#plt.xlabel("No. of Restaurant",size=15)
#plt.show()

#---------------------------------------------------------------------------------------
#online order facility
#Name = 'Yes', 'No'
#colors = ["#ff9999", "#66b3ff"]
#zomato_df['online_order'].value_counts().plot.pie(autopct='%1.1f%%',shadow=True,labels=Name, colors=colors ,rotatelabels=True)
#plt.title("Online order facility",fontweight="bold",fontsize=15)
#plt.show()

#---------------------------------------------------------------------------------------
#Book Table facility
#Name = 'Yes', 'No'
#colors = ["#E3CF57", "#20B2AA"]
#zomato_df['book_table'].value_counts().plot.pie(autopct='%1.1f%%',shadow=True,labels=Name, colors=colors ,rotatelabels=True)
#plt.title("Book Table facility",fontweight="bold",fontsize=20)
#plt.show()

#---------------------------------------------------------------------------------------
#Ratings v/s Rest. having online facility or not
#plt.figure(figsize = (6,6))
#sns.boxplot(x = 'online_order', y = 'rate', data = zomato_df)
#plt.title('Restaurant having online facility or not & Their Ratings')
#plt.show()

#---------------------------------------------------------------------------------------
#Visualizing Online Order Facility, Location Wise
df1 = zomato_df.groupby(['location','online_order'])['name'].count()
df1.to_csv('location_online.csv')
df1 = pd.read_csv('location_online.csv')
df1 = pd.pivot_table(df1,  index=['location'], columns=['online_order'])
#print(df1)

#df1.plot(kind = 'bar', figsize = (15,8))
#plt.title('Visualizing Online Order Facility Location Wise')
#plt.show()

#---------------------------------------------------------------------------------------
#Visualizing Book Table Facility, Location Wise
df2 = zomato_df.groupby(['location','book_table'])['name'].count()
df2.to_csv('location_booktable.csv')
df2 = pd.read_csv('location_booktable.csv')
df2 = pd.pivot_table(df2, index=['location'], columns=['book_table'])
#print(df2)

#df2.plot(kind = 'bar', figsize = (15,8))
#plt.title('Visualizing Book Table Facility, Location Wise')
#plt.show()

#---------------------------------------------------------------------------------------
#Visualizing Types of Restaurents vs Rate
#plt.figure(figsize = (14, 8))
#sns.lineplot(x = 'Type', y = 'rate', data = zomato_df, palette = 'inferno')
#plt.title('Visualizing Types of Restaurents vs Their Ratings')
#plt.show()


#---------------------------------------------------------------------------------------
#Visualizing Top Cuisines
df6 = zomato_df[['cuisines', 'votes']]
df6.drop_duplicates()
df7 = df6.groupby(['cuisines'])['votes'].sum()
df7 = df7.to_frame()
df7 = df7.sort_values('votes', ascending=False)
#print(df7.head())
df7 = df7.iloc[1:, :]
#print(df7.head())

#plt.figure(figsize = (15,8))
#sns.lineplot(df7.index , df7['votes'])
#plt.title('Visualizing Top Cuisines')
#plt.xticks(rotation = 90)
#plt.show()


